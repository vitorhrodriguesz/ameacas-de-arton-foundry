# Auditoria de automação — v1.5.0

Base: 430 fichas de Ameaças de Arton, Foundry VTT 13 / Tormenta20 1.5.015.

## Resultado

- Ataques revisados: **648**
  - Corpo a corpo / Luta: **572**
  - À distância / Pontaria: **76**
- Habilidades revisadas: **1326**
- Habilidades com rolagens estruturadas: **435**
- Rolagens de manobra adicionadas: **87**
- Rolagens de perda de PM adicionadas: **26**
- Habilidades com resistência estruturada: **342**
- Efeitos opcionais de condição: **429**
- Ajustes de CD específicos de habilidade: **13**
- Usos de magia estruturados: **314** em **61** ameaças conjuradoras
- Magias com CD especial: **10**
- Erros na validação estática final: **0**

## Regras de implementação

1. Ataques corpo a corpo usam `luta`; arremesso e disparo usam `pont`.
2. O bônus publicado é preservado por meio da perícia do ator + offset do Item.
3. Items são criados em NPC com `statblockParsing: true` para preservar o roll configurado.
4. Magias tentam herdar a implementação do compêndio `tormenta20.magias`; os números da ameaça prevalecem.
5. Habilidades tentam aproveitar Active Effects nativos, mas não herdam números genéricos que possam substituir valores específicos do livro.
6. Passivas nativas de transferência ficam protegidas contra dupla aplicação, pois os valores finais já constam no bloco estatístico.
7. Condições causadas por acerto/falha em resistência ficam como opções de uso para o GM decidir no momento correto.

## Correção de fonte

A lista de cinco magias do **Centauro xamã de Megalokk** foi recomposta diretamente do PDF fornecido, pois a extração anterior terminou no rodapé da página 105 e perdeu a continuação da página 106.

## Limite da auditoria

A validação foi feita sobre JSON, fórmulas, enums, caminhos e código de importação. A execução completa das 430 fichas dentro de uma instância real do Foundry VTT não foi simulada neste ambiente.
