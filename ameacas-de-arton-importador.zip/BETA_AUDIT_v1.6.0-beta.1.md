# Ameaças de Arton — auditoria v1.6.0-beta.1

Este arquivo registra o snapshot **parcial** solicitado pelo usuário. A auditoria completa ainda não foi encerrada.

## Alterações já aplicadas neste snapshot

- PM corrigidos em 97 fichas a partir da presença/ausência explícita de Pontos de Mana no bloco isolado do livro.
- PV corrigidos em 20 fichas quando divergiam do bloco isolado.
- ND corrigidos em 4 fichas somente quando havia um único ND inequívoco no bloco isolado.
- Valores-base de atributos corrigidos em 0 campos.
- Tipos de criatura corrigidos em 2 fichas; tamanhos corrigidos em 6.
- Defesa corrigida em 359 fichas quando divergente.
- 8 perícias explicitamente impressas no livro foram estruturadas/recalculadas.
- 653 ataques foram normalizados para Luta/Pontaria com atributo explícito e delta por arma, preservando o bônus publicado.
- 7 armas foram reconstruídas nos casos já confirmados manualmente nesta etapa.
- Servos do Dragão (Acólito de Kally): 2d4+1 agora é uma rolagem separada de Quantidade Invocada; 1d6-1 permanece como Dano dos Kobolds.

## Casos pontuais já reconstruídos

- Mamute Esqueleto: Presas +26 (2d8+26, 19) e Duas Pancadas +26 (1d6+19).
- Velocis Caçador: Lança +17 (1d6+9 mais veneno) e Azagaia +17 (1d6+11 mais veneno).
- Golem de Carne: Duas Pancadas +27 (2d10+23).
- Pistoleiro: Adaga +12 (1d4+5, 19) adicionada.
- Líder Pistoleiro: Adaga +16 (1d4+7, 19) adicionada.
- Grande Battham: tamanho Colossal.
- Trog Anão Bruto e Trog Anão Eremita: tipo Monstro.

## Validação estática

- Atores: 430.
- Inconsistências encontradas na recomposição estática dos bônus publicados dos ataques: 0.
- Compatibilidade-alvo: Foundry VTT 13 + Tormenta20 1.5.015.

## Limitação

Esta é uma beta de trabalho. Habilidades, passivas, magias, resistências, imunidades, vulnerabilidades e casos de diagramação complexa ainda não passaram pela auditoria final completa.
