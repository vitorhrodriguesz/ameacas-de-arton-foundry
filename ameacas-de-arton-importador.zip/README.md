# Ameaças de Arton — Foundry VTT 13 / Tormenta20 1.5.015

Versão do módulo: **1.4.2**

## Organização

Esta versão cria **um único Compendium de Actors chamado `Ameaças de Arton`**.
Dentro dele, as 430 fichas são organizadas em **pastas internas por ND**:

- ND 1/4
- ND 1/2
- ND 1 a ND 20
- ND S
- ND S+
- ND Dinâmico (?) quando aplicável

Cada pasta ordena suas criaturas alfabeticamente.

## O que permanece

- 430 fichas de ameaças.
- Tokens/portraits ilustrados derivados do PDF fornecido pelo usuário para uso pessoal.
- Importação resiliente: uma ficha problemática não interrompe as demais.
- Ataques e dados continuam no schema do Tormenta20 1.5.015.
- Relatório de falhas disponível no console.

## Atualização da versão 1.1

A versão 1.1 criava vários compêndios, um para cada ND. A versão 1.2 **não apaga esses packs antigos automaticamente**, para evitar perder eventuais edições feitas pelo Mestre.

Depois de confirmar que o novo compêndio único está correto, você pode remover os antigos pelo console (F12):

`await game.modules.get("ameacas-de-arton-importador").api.removeLegacyNDPacks()`

## Recriar o compêndio único

Como Mestre, no console:

`await game.modules.get("ameacas-de-arton-importador").api.rebuildCompendium()`

## Diagnóstico

Para ver o relatório da última importação:

`game.settings.get("ameacas-de-arton-importador", "lastImportReport")`

## Instalação por Manifest URL

Mantendo `module.json` e `ameacas-de-arton-importador.zip` na raiz da branch `main`:

`https://raw.githubusercontent.com/vitorhrodriguesz/ameacas-de-arton-foundry/main/module.json`

## Imagens e uso

As imagens deste pacote derivam do PDF fornecido pelo usuário e são destinadas ao uso pessoal na mesa. Não publique/distribua uma versão com as artes do livro sem autorização dos titulares dos direitos.


## Revisão de tokens na versão 1.3

- Revisão individual de tokens cortados, vazios ou bugados.
- 36 fichas receberam um novo token revisado.
- Onde não havia ilustração utilizável no PDF, foi aplicado um placeholder legível com nome, tipo e ND.


## Segunda revisão agressiva de tokens (v1.4.0)

- Nova passada manual focada em substituir placeholders por **arte reaproveitada do próprio PDF** sempre que havia uma opção aceitável.
- Quando não existia arte exata, em alguns casos foi usado **proxy temático** da mesma família visual da ameaça, priorizando legibilidade no token.
- Resultado desta segunda revisão: **30 tokens revisados com arte** e **6 tokens com placeholder mantido** por falta de ilustração realmente aproveitável.
- Placeholders mantidos: Cardume de aquin’ne, Governador corrupto, Iniciada de Sszzaas, Necrodraco lich, Totem do Pai-de-Tudo, Totem do Rei-Tirano.


## Complemento visual temático (v1.4.1)

- Os 6 tokens que ainda estavam com placeholder receberam **novas artes temáticas originais**, criadas para combinar com a linguagem visual das outras fichas.
- Alvos substituídos: Cardume de aquin’ne, Governador corrupto, Iniciada de Sszzaas, Necrodraco lich, Totem do Pai-de-Tudo e Totem do Rei-Tirano.
- O foco foi manter um visual coerente de **ilustração fantástica pintada para token**, com fundo transparente e leitura boa no Foundry.


## Otimização para GitHub (v1.4.2)

- Os 6 tokens temáticos de alta resolução foram redimensionados para até **640 px** e convertidos para **WebP com transparência**.
- Foram removidas montagens de revisão que não são necessárias para o funcionamento do módulo.
- A qualidade continua adequada para tokens no Foundry, mas o ZIP foi reduzido para ficar abaixo do limite de 25 MB do upload web do GitHub.
