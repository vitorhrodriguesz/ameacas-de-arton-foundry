# Ameaças de Arton — Foundry VTT 13 / Tormenta20 1.5.015

Versão do módulo: **1.2.0**

## Organização

Esta versão cria **um único Compendium de Actors chamado `Ameaças de Arton`**.
Dentro dele, as 430 fichas são organizadas em **pastas internas por ND**:

- ND 1/4
- ND 1/2
- ND 1 a ND 20
- ND S
- ND S+
- ND Dinâmico (?) quando aplicável

Cada pasta ordena suas criaturas alfabeticamente.

## O que permanece

- 430 fichas de ameaças.
- Tokens/portraits ilustrados derivados do PDF fornecido pelo usuário para uso pessoal.
- Importação resiliente: uma ficha problemática não interrompe as demais.
- Ataques e dados continuam no schema do Tormenta20 1.5.015.
- Relatório de falhas disponível no console.

## Atualização da versão 1.1

A versão 1.1 criava vários compêndios, um para cada ND. A versão 1.2 **não apaga esses packs antigos automaticamente**, para evitar perder eventuais edições feitas pelo Mestre.

Depois de confirmar que o novo compêndio único está correto, você pode remover os antigos pelo console (F12):

`await game.modules.get("ameacas-de-arton-importador").api.removeLegacyNDPacks()`

## Recriar o compêndio único

Como Mestre, no console:

`await game.modules.get("ameacas-de-arton-importador").api.rebuildCompendium()`

## Diagnóstico

Para ver o relatório da última importação:

`game.settings.get("ameacas-de-arton-importador", "lastImportReport")`

## Instalação por Manifest URL

Mantendo `module.json` e `ameacas-de-arton-importador.zip` na raiz da branch `main`:

`https://raw.githubusercontent.com/vitorhrodriguesz/ameacas-de-arton-foundry/main/module.json`

## Imagens e uso

As imagens deste pacote derivam do PDF fornecido pelo usuário e são destinadas ao uso pessoal na mesa. Não publique/distribua uma versão com as artes do livro sem autorização dos titulares dos direitos.
