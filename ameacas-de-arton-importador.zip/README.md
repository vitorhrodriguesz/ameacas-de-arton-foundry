# Ameaças de Arton — Foundry VTT 13 / Tormenta20 1.5.015

Versão do módulo: **1.1.0**

## O que mudou

- 430 fichas de ameaças.
- Compêndios separados por ND (1/4, 1/2, 1 a 20, S, S+ e ND dinâmico quando aplicável).
- Tokens/portraits ilustrados extraídos do PDF fornecido pelo usuário para uso pessoal.
- Importador mais tolerante a erros: uma ficha inválida não interrompe as demais.
- IDs e metadados de exportação são limpos antes da criação dos documentos no Foundry.
- Ataques à distância usam o valor de schema `disparo` (o valor antigo `distancia` não é aceito pelo Tormenta20 1.5.015).
- Tamanho do Prototype Token é normalizado conforme o tamanho da criatura.
- Relatório de falhas disponível no console do Foundry.

## Instalação manual

Extraia o conteúdo em `Data/modules/ameacas-de-arton-importador/` e ative o módulo no mundo Tormenta20.

## Instalação por Manifest URL

Se você hospedar `module.json` e `ameacas-de-arton-importador.zip` na raiz da branch `main`, use:

`https://raw.githubusercontent.com/vitorhrodriguesz/ameacas-de-arton-foundry/main/module.json`

## Diagnóstico

Se alguma ficha falhar, abra F12 > Console e execute:

`game.settings.get("ameacas-de-arton-importador", "lastImportReport")`

O objeto retornado lista os nomes das fichas e as mensagens de erro.

Também é possível refazer a importação manualmente pelo console:

`await game.modules.get("ameacas-de-arton-importador").api.rebuildCompendiums()`

## Sobre o compêndio antigo

A versão 1.0 criava um único compêndio de mundo chamado **Ameaças de Arton**. Esta versão não apaga esse compêndio automaticamente para não destruir eventuais edições do mestre. Depois de confirmar que os novos compêndios por ND funcionam, você pode apagar manualmente o compêndio antigo.

## Imagens e uso

As imagens deste pacote derivam do PDF que você forneceu e são destinadas ao seu uso pessoal na mesa. Não publique/distribua uma versão com as artes do livro em um repositório público sem a autorização dos titulares dos direitos. Para um manifesto público, prefira uma versão sem essas imagens ou hospedagem autorizada.

Cobertura de imagens: 430/430 atores, usando 205 imagens de origem.
