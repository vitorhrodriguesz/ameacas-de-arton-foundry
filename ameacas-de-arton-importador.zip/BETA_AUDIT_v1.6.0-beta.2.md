# Ameaças de Arton — auditoria v1.6.0-beta.2

Snapshot parcial da continuação da auditoria dos 430 atores contra o PDF fornecido.

## Correções desta etapa

- **20 fichas**: PV corrigidos quando o separador de milhar do livro havia sido interpretado como decimal/truncado (por exemplo, 1.400 → 1).
- **2 fichas**: PM restaurados após conferência direta do bloco impresso (Bispo do Forte Sagrado e Dracomante Superior).
- **2 fichas**: `base` e `value` de Defesa sincronizados com o valor publicado (Mega-Selako e Pakk).
- **5 fichas**: tamanho corrigido (Burodron, Cemitério Vivo, Dejeto Vivo, Dragão Celestial Adulto e Necrodraco Lich).
- **3 fichas**: subtipo/raça estruturado corrigido (dois Trogs Anões e Protetor-Refém).
- **50 fichas**: campos estruturados de redução, imunidade e vulnerabilidade de dano reconstruídos de forma conservadora a partir da linha defensiva publicada; foram alterados **83 valores escalares**.

## Correção importante de parser

Na beta.1, diversas fichas que possuíam `imunidade a X, ... vulnerabilidade a Y` acabavam marcando Y simultaneamente como **imunidade e vulnerabilidade** por causa do alcance excessivo da expressão de extração. A beta.2 separa os segmentos e só estrutura tipos de dano explicitamente presentes em cada cláusula.

## Casos deliberadamente não inferidos

- `Velocis Caçador`: o trecho extraído continha `Pontos de Mana 34`, mas a conferência da página 268 mostra que esse valor pertence à ficha vizinha **Xamã de Sarana**. A ficha do Velocis continua sem PM.
- Atributos impressos como `—` não foram convertidos automaticamente para `-5`; isso exige decisão específica sobre a representação suportada pelo schema do Tormenta20.
- Exceções textuais de RD (`RD 20/luz`, `RD 5/mágico` etc.) permanecem preservadas em `detalhes.resistencias`. O valor-base é estruturado, mas não foi inventado um campo de exceção textual que o schema atual não oferece.

## Estado

A auditoria completa ainda não está encerrada. Próximas frentes: imunidades/condições não-dano, resistências a efeitos, habilidades passivas especiais, custos/recargas e revisão manual dos blocos com diagramação contaminada por colunas vizinhas.
