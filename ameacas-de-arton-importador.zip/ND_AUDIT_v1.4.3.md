# Auditoria de ND e pastas — v1.4.3

Base da conferência: índice por ND do PDF Ameaças de Arton fornecido pelo usuário.

- Fichas conferidas: **430**.
- Divergências entre o ND gravado na ficha e o índice do livro: **0**.
- Cabeçalhos de fonte/ND conferidos: **429 fichas regulares + Rival Espelho (ND variável ?) validado separadamente**.
- Causa corrigida para fichas em pasta errada: associação de Folder por posição do array retornado pelo Foundry. A v1.4.3 associa cada pasta pelo ND persistido em flag/nome e valida a correspondência antes de importar.
- Ordem das pastas: **ND 1/4, ND 1/2, ND 1, ND 2, …, ND 20, ND S, ND S+, ND Dinâmico (?)**.

## Quantidade de fichas por ND

- ND 1/4: 5
- ND 1/2: 17
- ND 1: 40
- ND 2: 46
- ND 3: 37
- ND 4: 27
- ND 5: 40
- ND 6: 30
- ND 7: 24
- ND 8: 36
- ND 9: 12
- ND 10: 20
- ND 11: 15
- ND 12: 17
- ND 13: 8
- ND 14: 14
- ND 15: 9
- ND 16: 10
- ND 17: 4
- ND 18: 4
- ND 19: 3
- ND 20: 4
- ND S: 4
- ND S+: 3
- ND ?: 1