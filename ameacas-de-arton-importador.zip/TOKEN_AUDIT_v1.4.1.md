# Auditoria de tokens — versão 1.4.1

Os 6 tokens que ainda estavam com placeholder na v1.4.0 foram substituídos por artes temáticas originais nesta versão.

- Tokens problemáticos revisados anteriormente: 36
- Tokens com arte após v1.4.1: 36
- Placeholders restantes: 0

## Substituições feitas

- Cardume de aquin’ne — nova arte temática original (enxame elemental aquático).
- Governador corrupto — nova arte temática original (minotauro nobre tirânico).
- Iniciada de Sszzaas — nova arte temática original (medusa sacerdotisa/assassina).
- Necrodraco lich — nova arte temática original (dragão morto-vivo arcano).
- Totem do Pai-de-Tudo — nova arte temática original (totem solar bestial e celestial).
- Totem do Rei-Tirano — nova arte temática original (totem reptiliano tirânico espiritual).