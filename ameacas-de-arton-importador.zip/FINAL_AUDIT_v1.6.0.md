# Ameaças de Arton — auditoria final v1.6.0

## Escopo

- **430 atores** auditados contra o PDF fornecido.
- Comparação de cabeçalho: Iniciativa, Percepção, Defesa, Fortitude, Reflexos, Vontade, PV e PM quando presentes.
- Comparação de ND, atributos, perícias explicitamente listadas, sentidos e traços defensivos.
- Revisão conservadora de itens para remover armas/habilidades confirmadamente copiadas de uma ficha vizinha.

## Resultado da validação

- **0 divergências** no validador final de fonte para os campos numéricos cobertos.
- **0 erros** na validação estrutural do pacote (IDs, rolls, finalidades de armas, tipos de dano/cura, imagens e ND).
- **429** blocos com cabeçalho numérico validados.
- **697** entradas explícitas de perícia comparadas e reproduzidas.
- **41** itens contaminados por blocos vizinhos removidos.
- **4** correções de ND/nível estruturado.
- **93** valores de atributos alterados em **51** atores em relação à beta.2.
- **45** atores possuem ao menos um atributo impresso como “—”; a informação original fica registrada em flag.
- **360** atores tiveram sentidos estruturados revisados.
- **120** atores tiveram imunidades de condição/efeito estruturadas revisadas.
- **22** atores tiveram resistências/imunidades/vulnerabilidades de dano estruturadas alteradas em relação à beta.2.

## Correções importantes descobertas na passagem final

- O **Elemental do Veneno Médio** estava com ND 2 na estrutura, apesar de ser ND 8; ND, nível e treino foram sincronizados.
- **Gatzvalith**, **Sckhar** e **Tarso** voltaram a usar ND **S+** em vez de serem colapsados para S.
- Foram corrigidos atributos contaminados em fichas como Kaijin Capanga, Mamute, Mamute Esqueleto, Quimera, Unicórnio, Velocis Caçador, Homúnculo e as Fúrias de Tauron.
- Foram removidos itens comprovadamente pertencentes à ficha vizinha (ex.: habilidades da Xamã de Sarana no Velocis Caçador; partes do Mamute no Golem de Nor Enorme).

## Representação no Foundry

- O sistema Tormenta20 1.5.015 calcula perícias a partir de meio nível + atributo + treino + ajustes. Por isso, após corrigir atributos/ND, os campos `outros` foram recalibrados para manter exatamente os totais impressos.
- O schema exige atributo numérico. Para um atributo impresso como `—`, foi usado `-5` como menor valor aceito e a flag `flags.ameacasDeArton.absentAttributes` preserva explicitamente a informação de que a fonte usa traço.
- RD com exceção de tipo de dano suportado (como `20/luz`) usa o campo `excecao`. Exceções não representáveis com segurança pelo schema (como `/mágico`) permanecem no texto da resistência sem aproximação indevida.

## Limites da validação

- A validação final é **estática/estrutural** sobre os dados do módulo e a fonte fornecida. Não foi executada uma sessão real do Foundry nesta máquina.
- Efeitos narrativos ou regras cuja semântica não possui campo estruturado equivalente no sistema continuam preservados no texto da ficha, em vez de receber automação especulativa.
