# Auditoria textual — versão 1.4.4

Foi feita uma revisão conservadora dos textos das 430 fichas. A limpeza remove apenas repetições exatas/adjacentes produzidas pela extração, títulos repetidos no início das descrições e quebras artificiais de palavras. Não houve reescrita de regras nem alteração de valores numéricos.

## Resumo

- Fichas revisadas: **430**
- Fichas com algum ajuste: **430**
- Biografias/blocos de texto ajustados: **430**
- Descrições de itens/poderes ajustadas: **1810**
- Blocos de linhas duplicados removidos: **59**
- Frases/trechos adjacentes duplicados colapsados: **12**
- Palavras adjacentes duplicadas colapsadas: **19**
- Prefixos de título repetidos removidos das descrições: **1805**
- Quebras artificiais de palavras reparadas: **232**
- Itens exatamente duplicados removidos: **0**

## Critério

- Mantido o texto-fonte e a terminologia das fichas.
- Removidas apenas repetições exatas/adjacentes e artefatos evidentes de extração.
- Nenhum valor de ND, PV, Defesa, testes, dano ou CD foi recalculado nesta etapa.
- A organização por ND da versão 1.4.3 foi preservada.