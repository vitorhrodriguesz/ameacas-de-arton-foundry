const MODULE_ID = "ameacas-de-arton-importador";
const PACK_NAME = "ameacas-de-arton";
const PACK_COLLECTION = `world.${PACK_NAME}`;
const DATA_URL = new URL("../data/actors.json", import.meta.url);

// Ordem visual do compêndio: NDs fracionários, 1 a 20, depois NDs em letras e o ND dinâmico.
const ND_ORDER = ["1/4", "1/2", ...Array.from({length: 20}, (_, i) => String(i + 1)), "S", "S+", "?"];

function ndSortKey(nd) {
  const i = ND_ORDER.indexOf(nd);
  return i >= 0 ? i : ND_ORDER.length + 100;
}

function ndFolderLabel(nd) {
  if (nd === "?") return "ND Dinâmico (?)";
  return `ND ${nd}`;
}

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "importedVersion", {
    name: "Versão já importada",
    scope: "world",
    config: false,
    type: String,
    default: ""
  });
  game.settings.register(MODULE_ID, "lastImportReport", {
    name: "Relatório da última importação",
    scope: "world",
    config: false,
    type: Object,
    default: {}
  });
});

async function loadActors() {
  const response = await fetch(DATA_URL);
  if (!response.ok) throw new Error(`Não foi possível ler actors.json (${response.status}).`);
  const data = await response.json();
  if (!Array.isArray(data)) throw new Error("actors.json não contém uma lista de atores.");
  return data;
}

function cleanActiveEffect(effect) {
  const e = foundry.utils.deepClone(effect);
  delete e._id;
  delete e._stats;
  // O origin de um efeito vindo de compêndio aponta para o Item original. Ao remover,
  // o Foundry pode vincular o efeito ao novo Item embutido sem um ID obsoleto.
  delete e.origin;
  return e;
}

function cleanEmbeddedItem(item) {
  const i = foundry.utils.deepClone(item);
  delete i._id;
  delete i._stats;
  delete i.folder;
  delete i.ownership;
  if (Array.isArray(i.effects)) i.effects = i.effects.map(cleanActiveEffect);
  return i;
}

function normalizeLookupName(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\*+$/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function weaponLookupCandidates(item) {
  const raw = item.flags?.[MODULE_ID]?.nativeLookup ?? item.name ?? "";
  const names = [raw];
  let cleaned = String(raw)
    .replace(/^\s*\[[^\]]+\]\s*/i, "")
    .replace(/\s+x\d+\s*$/i, "")
    .replace(/^(duas|dois|tr[eê]s|quatro|cinco|seis)\s+/i, "")
    .trim();
  if (cleaned && cleaned !== raw) names.push(cleaned);
  // Alguns ataques naturais aparecem no plural no bloco, enquanto o item nativo é singular.
  if (/pancadas$/i.test(cleaned)) names.push(cleaned.replace(/pancadas$/i, "Pancada"));
  if (/mordidas$/i.test(cleaned)) names.push(cleaned.replace(/mordidas$/i, "Mordida"));
  return [...new Set(names.map(normalizeLookupName).filter(Boolean))];
}

let nativeCatalogPromise = null;
const nativeDocumentCache = new Map();

async function getNativeCatalog() {
  if (nativeCatalogPromise) return nativeCatalogPromise;
  nativeCatalogPromise = (async () => {
    const result = { spells: new Map(), powers: new Map(), weapons: new Map(), missingPacks: [] };
    const defs = [
      { id: "tormenta20.magias", target: "spells", types: new Set(["magia"]) },
      { id: "tormenta20.habilidades-de-criaturas", target: "powers", types: new Set(["poder"]) },
      { id: "tormenta20.habilidades-de-criaturas", target: "weapons", types: new Set(["arma"]) },
      { id: "tormenta20.poderes", target: "powers", types: new Set(["poder"]) },
      { id: "tormenta20.equipamentos", target: "weapons", types: new Set(["arma"]) },
      { id: "tormenta20.equipamentos-magicos", target: "weapons", types: new Set(["arma"]) }
    ];
    for (const def of defs) {
      const pack = game.packs.get(def.id);
      if (!pack) {
        if (!result.missingPacks.includes(def.id)) result.missingPacks.push(def.id);
        continue;
      }
      try {
        const index = await pack.getIndex({ fields: ["type"] });
        for (const entry of index) {
          if (entry.type && !def.types.has(entry.type)) continue;
          const key = normalizeLookupName(entry.name);
          if (!key || result[def.target].has(key)) continue;
          result[def.target].set(key, { packId: def.id, id: entry._id ?? entry.id, name: entry.name, type: entry.type });
        }
      } catch (err) {
        console.warn(`${MODULE_ID} | Não foi possível indexar ${def.id}`, err);
      }
    }
    return result;
  })();
  return nativeCatalogPromise;
}

async function getNativeItem(entry) {
  if (!entry?.packId || !entry?.id) return null;
  const cacheKey = `${entry.packId}:${entry.id}`;
  if (nativeDocumentCache.has(cacheKey)) return foundry.utils.deepClone(nativeDocumentCache.get(cacheKey));
  const pack = game.packs.get(entry.packId);
  if (!pack) return null;
  const doc = await pack.getDocument(entry.id);
  if (!doc) return null;
  const data = cleanEmbeddedItem(doc.toObject());
  nativeDocumentCache.set(cacheKey, data);
  return foundry.utils.deepClone(data);
}

function effectSignature(effect) {
  return `${normalizeLookupName(effect?.name)}|${JSON.stringify(effect?.changes ?? [])}`;
}

function mergeEffects(nativeEffects = [], localEffects = []) {
  const output = [];
  const seen = new Set();
  for (const source of [...nativeEffects, ...localEffects]) {
    const effect = cleanActiveEffect(source);
    const sig = effectSignature(effect);
    if (seen.has(sig)) continue;
    seen.add(sig);
    output.push(effect);
  }
  return output;
}

function guardNativePassiveEffects(effects = []) {
  return effects.map(source => {
    const effect = cleanActiveEffect(source);
    const onuse = !!effect.flags?.tormenta20?.onuse;
    // Os blocos de ameaça já trazem Defesa, perícias, RD etc. com passivas contabilizadas.
    // Um ActiveEffect de transferência ativo herdado do compêndio do sistema poderia somar o
    // mesmo bônus de novo. Mantemos a automação disponível, mas desligada por padrão.
    if (effect.transfer && !onuse && effect.disabled === false) {
      effect.disabled = true;
      effect.flags ??= {};
      effect.flags[MODULE_ID] = { ...(effect.flags[MODULE_ID] ?? {}), passiveGuard: true };
    }
    return effect;
  });
}

function makeCDEffect(targetCD, offset) {
  return {
    name: `Ajuste de CD: ${targetCD}`,
    img: "icons/svg/d20.svg",
    type: "base",
    system: {},
    changes: [{ key: "cd", mode: 2, value: String(offset), priority: 0 }],
    disabled: false,
    duration: { startTime: null, seconds: null, combat: null, rounds: null, turns: null, startRound: null, startTurn: null },
    transfer: false,
    flags: { tormenta20: { onuse: true, self: true, durationScene: false } },
    tint: "#ffffff",
    description: "Ajusta a CD desta magia em relação à CD global da ameaça.",
    statuses: [],
    sort: 0
  };
}

function makeConditionEffect(condition, sort = 0) {
  return {
    name: `Aplicar condição: ${condition}`,
    img: "icons/svg/aura.svg",
    type: "base",
    system: {},
    changes: [{ key: "condicao", mode: 0, value: condition, priority: null }],
    disabled: true,
    duration: { startTime: null, seconds: null, combat: null, rounds: null, turns: null, startRound: null, startTurn: null },
    transfer: false,
    flags: { tormenta20: { onuse: true, durationScene: true } },
    tint: "#ffffff",
    description: "",
    statuses: [],
    sort
  };
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>'"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[ch]);
}

function applyParsedPowerFields(target, local) {
  target.system ??= {};
  const src = local.system ?? {};
  const automation = local.flags?.[MODULE_ID] ?? {};
  if (Number(src.ativacao?.custo) > 0) {
    target.system.ativacao ??= {};
    target.system.ativacao.custo = Number(src.ativacao.custo);
  }
  if (src.alcance && src.alcance !== "none") target.system.alcance = src.alcance;
  if (src.duracao && (src.duracao.units !== "inst" || src.duracao.value || src.duracao.special)) {
    target.system.duracao = foundry.utils.deepClone(src.duracao);
  }
  if (src.resistencia?.txt) target.system.resistencia = foundry.utils.deepClone(src.resistencia);
  if (Array.isArray(src.rolls) && src.rolls.length) target.system.rolls = foundry.utils.deepClone(src.rolls);
  target.system.description = foundry.utils.deepClone(src.description ?? target.system.description);
  target.system.source = src.source ?? target.system.source ?? "Ameaças de Arton";
  target.system.chatFlavor = src.chatFlavor ?? target.system.chatFlavor ?? "";
  target.flags ??= {};
  target.flags[MODULE_ID] = foundry.utils.deepClone(automation);
  target.effects = mergeEffects(target.effects ?? [], local.effects ?? []);
  target.name = local.name;
  return target;
}

async function hydrateWeapon(item, catalog, stats) {
  const candidates = weaponLookupCandidates(item);
  let entry = null;
  for (const key of candidates) {
    entry = catalog.weapons.get(key);
    if (entry) break;
  }
  if (!entry) return item;
  try {
    const native = await getNativeItem(entry);
    if (!native || native.type !== "arma") return item;
    // Metadados físicos/propriedades vêm do item oficial do sistema, mas ataque, dano,
    // crítico e finalidade usada por esta ameaça permanecem conforme o bloco estatístico.
    native.name = item.name;
    native.system.description = foundry.utils.deepClone(item.system.description);
    native.system.source = item.system.source ?? "Ameaças de Arton";
    native.system.chatFlavor = item.system.chatFlavor ?? "";
    native.system.rolls = foundry.utils.deepClone(item.system.rolls ?? []);
    native.system.criticoM = item.system.criticoM;
    native.system.criticoX = item.system.criticoX;
    native.system.proposito = item.system.proposito;
    native.system.ataques = item.system.ataques ?? native.system.ataques ?? 0;
    native.flags ??= {};
    native.flags[MODULE_ID] = foundry.utils.deepClone(item.flags?.[MODULE_ID] ?? {});
    native.effects = mergeEffects(native.effects ?? [], item.effects ?? []);
    stats.weaponsNative++;
    return native;
  } catch (err) {
    stats.hydrationErrors.push({ type: "weapon", name: item.name, error: err?.message ?? String(err) });
    return item;
  }
}

async function hydratePower(item, catalog, stats) {
  const lookup = normalizeLookupName(item.flags?.[MODULE_ID]?.nativeLookup ?? item.name);
  const entry = catalog.powers.get(lookup);
  if (!entry) return item;
  try {
    const native = await getNativeItem(entry);
    if (!native || native.type !== "poder") return item;

    // O texto e todos os números permanecem os do bloco de Ameaças de Arton.
    // Do item nativo herdamos apenas arte/metadados não numéricos e ActiveEffects, evitando
    // que uma habilidade genérica do sistema (por exemplo Veneno) substitua dano/CD próprios.
    const local = cleanEmbeddedItem(item);
    if (native.img) local.img = native.img;
    local.system ??= {};
    for (const field of ["rolltags", "automationtags", "tags"]) {
      if ((!Array.isArray(local.system[field]) || !local.system[field].length) && Array.isArray(native.system?.[field])) {
        local.system[field] = foundry.utils.deepClone(native.system[field]);
      }
    }
    local.effects = mergeEffects(guardNativePassiveEffects(native.effects ?? []), local.effects ?? []);
    stats.powersNative++;
    return local;
  } catch (err) {
    stats.hydrationErrors.push({ type: "power", name: item.name, error: err?.message ?? String(err) });
    return item;
  }
}

function applySpellSpecToNative(item, spec, actorCD) {
  item.name = spec.name;
  item.system ??= {};
  item.system.ativacao ??= {};
  if (spec.activation && spec.activation !== "passive") item.system.ativacao.execucao = spec.activation;
  item.system.ativacao.custo = Number(spec.cost ?? item.system.ativacao.custo ?? 0);
  if (spec.range && spec.range !== "none") item.system.alcance = spec.range;
  if (spec.area) item.system.area = spec.area;
  if (spec.target) item.system.alvo = spec.target;
  if (spec.duration && (spec.duration.units !== "inst" || spec.duration.value || spec.duration.special)) {
    item.system.duracao = foundry.utils.deepClone(spec.duration);
  }
  if (spec.save?.txt) {
    item.system.resistencia ??= {};
    item.system.resistencia.pericia = spec.save.pericia ?? "";
    item.system.resistencia.atributo = "";
    item.system.resistencia.bonus = 0;
    item.system.resistencia.txt = spec.save.txt;
  }
  if (Array.isArray(spec.rolls) && spec.rolls.length) item.system.rolls = foundry.utils.deepClone(spec.rolls);
  const baseDescription = item.system.description?.value ?? "";
  item.system.description ??= { value: "", unidentified: "" };
  item.system.description.value = `<section class="secret"><p><strong>Uso pela ameaça:</strong> ${escapeHTML(spec.text)}</p></section>${baseDescription}`;
  item.system.source = "Ameaças de Arton";
  const conditionEffects = (spec.conditions ?? []).map((c, i) => makeConditionEffect(c, (i + 1) * 1000));
  const cdEffects = [];
  const targetCD = Number(spec.targetCD ?? 0);
  const baseCD = Number(actorCD ?? 0);
  if (targetCD && baseCD && targetCD !== baseCD) cdEffects.push(makeCDEffect(targetCD, targetCD - baseCD));
  item.effects = mergeEffects(item.effects ?? [], [...conditionEffects, ...cdEffects]);
  item.flags ??= {};
  item.flags[MODULE_ID] = { generatedFromThreat: true, activation: spec.activation, sourceText: spec.text, targetCD: targetCD || null };
  return item;
}

function createSpellFallback(summaryItem, spec, actorCD) {
  const item = cleanEmbeddedItem(summaryItem);
  item.name = spec.name;
  item.type = "poder";
  item.system.description = { value: `<p><strong>${escapeHTML(spec.name)}.</strong> ${escapeHTML(spec.text)}</p>`, unidentified: "" };
  item.system.ativacao ??= {};
  item.system.ativacao.custo = Number(spec.cost ?? 0);
  item.system.alcance = spec.range ?? "none";
  item.system.area = spec.area ?? "";
  item.system.alvo = spec.target ?? "";
  item.system.duracao = foundry.utils.deepClone(spec.duration ?? { value: 0, units: "inst", special: "" });
  item.system.resistencia = { pericia: spec.save?.pericia ?? "", atributo: "", bonus: 0, txt: spec.save?.txt ?? "" };
  item.system.rolls = foundry.utils.deepClone(spec.rolls ?? []);
  item.system.chatFlavor = `Magia da ameaça — Execução: ${spec.activation ?? "action"}`;
  const effects = (spec.conditions ?? []).map((c, i) => makeConditionEffect(c, (i + 1) * 1000));
  const targetCD = Number(spec.targetCD ?? 0);
  const baseCD = Number(actorCD ?? 0);
  if (targetCD && baseCD && targetCD !== baseCD) effects.push(makeCDEffect(targetCD, targetCD - baseCD));
  item.effects = effects;
  item.flags ??= {};
  item.flags[MODULE_ID] = { generatedFromThreat: true, nativeSpellMissing: true, activation: spec.activation, targetCD: targetCD || null };
  return item;
}

async function hydrateActorData(actor, report = null) {
  const catalog = await getNativeCatalog();
  const stats = report?.automation ?? { weaponsNative: 0, powersNative: 0, spellsNative: 0, spellsFallback: 0, hydrationErrors: [], missingNativeSpells: [] };
  const originalItems = Array.isArray(actor.items) ? actor.items : [];
  const summaryItem = originalItems.find(i => i.type === "poder" && normalizeLookupName(i.name) === "magias") ?? null;
  const specs = actor.flags?.[MODULE_ID]?.spellSpecs ?? [];
  const hydrated = [];

  for (const item of originalItems) {
    if (specs.length && item === summaryItem) continue;
    if (item.type === "arma") hydrated.push(await hydrateWeapon(item, catalog, stats));
    else if (item.type === "poder") hydrated.push(await hydratePower(item, catalog, stats));
    else hydrated.push(item);
  }

  if (specs.length && summaryItem) {
    for (const spec of specs) {
      const entry = catalog.spells.get(normalizeLookupName(spec.name));
      if (entry) {
        try {
          let native = await getNativeItem(entry);
          if (native?.type === "magia") {
            native = applySpellSpecToNative(native, spec, actor.system?.attributes?.cd);
            hydrated.push(native);
            stats.spellsNative++;
            continue;
          }
        } catch (err) {
          stats.hydrationErrors.push({ type: "spell", name: spec.name, error: err?.message ?? String(err) });
        }
      }
      hydrated.push(createSpellFallback(summaryItem, spec, actor.system?.attributes?.cd));
      stats.spellsFallback++;
      if (!stats.missingNativeSpells.includes(spec.name)) stats.missingNativeSpells.push(spec.name);
    }
  }

  actor.items = hydrated;
  if (actor.flags?.[MODULE_ID]) delete actor.flags[MODULE_ID].spellSpecs;
  return actor;
}

function cleanActor(actor) {
  const a = foundry.utils.deepClone(actor);
  delete a._id;
  delete a._stats;
  delete a.folder;
  delete a.ownership;
  if (Array.isArray(a.items)) a.items = a.items.map(cleanEmbeddedItem);
  return a;
}

function getCompendiumClass() {
  return globalThis.foundry?.documents?.collections?.CompendiumCollection ?? globalThis.CompendiumCollection;
}

async function ensureSinglePack({ recreate = false } = {}) {
  let pack = game.packs.get(PACK_COLLECTION);
  if (pack && recreate) {
    try { await pack.configure({ locked: false }); } catch (_) {}
    await pack.deleteCompendium();
    pack = null;
  }
  if (pack) return pack;

  const CC = getCompendiumClass();
  if (!CC?.createCompendium) throw new Error("API CompendiumCollection.createCompendium não encontrada.");
  return await CC.createCompendium({
    name: PACK_NAME,
    label: "Ameaças de Arton",
    type: "Actor",
    package: "world",
    system: "tormenta20",
    ownership: { PLAYER: "LIMITED", ASSISTANT: "OWNER" }
  });
}

async function createNDFolders(pack, nds) {
  const folderData = nds.map((nd, index) => ({
    name: ndFolderLabel(nd),
    type: "Actor",
    folder: null,
    // Conteúdo da pasta (atores) em ordem alfabética.
    sorting: "a",
    // Pastas de nível superior usam sort manual no Foundry; isso fixa a ordem ND.
    sort: (index + 1) * 100000,
    flags: { [MODULE_ID]: { nd } }
  }));

  // Foundry v13 permite Folder dentro de Compendium via {pack}.
  const created = await Folder.createDocuments(folderData, { pack: pack.collection });

  // IMPORTANTE: não associar por índice do array retornado. O Foundry pode devolver
  // os documentos em uma ordem diferente da enviada. Essa era a origem possível de
  // fichas ND 3 aparecerem em pasta ND 2 (e vice-versa).
  const byND = new Map();
  const labelToND = new Map(nds.map(nd => [ndFolderLabel(nd), nd]));
  for (const folder of created) {
    const flaggedND = folder.flags?.[MODULE_ID]?.nd;
    const nd = flaggedND != null ? String(flaggedND) : labelToND.get(folder.name);
    if (nd && nds.includes(nd)) byND.set(nd, folder);
  }

  const missing = nds.filter(nd => !byND.has(nd));
  if (missing.length) {
    throw new Error(`Falha ao mapear pastas de ND: ${missing.join(", ")}`);
  }

  // Validação defensiva: a pasta vinculada a cada ND deve ter o nome esperado.
  for (const nd of nds) {
    const folder = byND.get(nd);
    const expected = ndFolderLabel(nd);
    if (folder?.name !== expected) {
      throw new Error(`Pasta de ND inconsistente: ND ${nd} foi associado a "${folder?.name}"; esperado "${expected}".`);
    }
  }
  return byND;
}

async function createActorsResilient(pack, sourceActors, folderByND, report) {
  let created = 0;
  for (const source of sourceActors) {
    const nd = String(source.system?.attributes?.nd ?? "?");
    try {
      const data = cleanActor(source);
      await hydrateActorData(data, report);
      const folder = folderByND.get(nd);
      if (folder) data.folder = folder.id;
      // IMPORTANTE: o sistema Tormenta20 limpa a perícia do ataque de armas de NPC
      // quando um Item é criado sem a opção statblockParsing. Criamos o ator primeiro e
      // depois os Itens com essa opção, exatamente como o importador oficial de ameaças.
      const embeddedItems = Array.isArray(data.items) ? data.items : [];
      data.items = [];
      const [createdActor] = await Actor.implementation.createDocuments([data], { pack: pack.collection });
      if (embeddedItems.length) {
        await createdActor.createEmbeddedDocuments("Item", embeddedItems, { statblockParsing: true });
      }
      created++;
      report.folders[nd].created++;
    } catch (err) {
      const entry = { nd, name: source.name, error: err?.message ?? String(err) };
      report.errors.push(entry);
      console.error(`${MODULE_ID} | Falha ao importar ${source.name}`, err, source);
    }
  }
  return created;
}

function validateActorNDs(actors) {
  const allowed = new Set(ND_ORDER);
  const invalid = [];
  for (const actor of actors) {
    const nd = String(actor.system?.attributes?.nd ?? "?");
    if (!allowed.has(nd)) invalid.push({ name: actor.name, nd });
  }
  if (invalid.length) {
    throw new Error(`Há ${invalid.length} ficha(s) com ND fora da lista suportada: ${invalid.map(e => `${e.name} (${e.nd})`).join(", ")}`);
  }
  return true;
}

/**
 * Recria UM único Compendium "Ameaças de Arton" e cria pastas internas por ND.
 * O pack alvo é recriado para garantir que não sobrem pastas/documentos de versões anteriores.
 */
async function rebuildCompendium({ notify = true } = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode criar/atualizar o compêndio.");
  if (game.system.id !== "tormenta20") throw new Error("Este módulo deve ser usado no sistema Tormenta20.");

  const actors = await loadActors();
  validateActorNDs(actors);
  const present = new Set(actors.map(a => String(a.system?.attributes?.nd ?? "?")));
  const nds = ND_ORDER.filter(nd => present.has(nd))
    .concat([...present].filter(nd => !ND_ORDER.includes(nd)).sort((a, b) => ndSortKey(a) - ndSortKey(b) || a.localeCompare(b, "pt-BR")));

  if (notify) ui.notifications.info("Ameaças de Arton: recriando um único compêndio com pastas por ND...");
  const pack = await ensureSinglePack({ recreate: true });
  try { await pack.configure({ locked: false }); } catch (_) {}

  const folderByND = await createNDFolders(pack, nds);
  const report = {
    version: game.modules.get(MODULE_ID)?.version ?? "",
    total: actors.length,
    created: 0,
    pack: pack.collection,
    folders: {},
    errors: [],
    automation: {
      weaponsNative: 0,
      powersNative: 0,
      spellsNative: 0,
      spellsFallback: 0,
      missingNativeSpells: [],
      hydrationErrors: []
    },
    timestamp: Date.now()
  };
  for (const nd of nds) {
    report.folders[nd] = {
      name: ndFolderLabel(nd),
      requested: actors.filter(a => String(a.system?.attributes?.nd ?? "?") === nd).length,
      created: 0,
      folderId: folderByND.get(nd)?.id ?? null
    };
  }

  report.created = await createActorsResilient(pack, actors, folderByND, report);
  try { await pack.configure({ locked: true }); } catch (_) {}

  await game.settings.set(MODULE_ID, "lastImportReport", report);
  if (report.errors.length) {
    ui.notifications.warn(`Ameaças de Arton: ${report.created}/${report.total} fichas importadas; ${report.errors.length} falharam. Veja F12 e game.settings.get('${MODULE_ID}', 'lastImportReport').`);
  } else if (notify) {
    ui.notifications.info(`Ameaças de Arton: ${report.created} fichas em um único compêndio, organizadas por ND.`);
  }
  return report;
}

// Alias para comandos usados na versão 1.1.
const rebuildCompendiums = rebuildCompendium;

async function importAllToWorld({ rootFolderName = "Ameaças de Arton" } = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode importar fichas para o mundo.");
  const actors = await loadActors();
  let root = game.folders.find(f => f.type === "Actor" && f.name === rootFolderName && !f.folder) ?? null;
  if (!root) root = await Folder.create({ name: rootFolderName, type: "Actor" });

  const groups = new Map();
  for (const actor of actors) {
    const nd = String(actor.system?.attributes?.nd ?? "?");
    if (!groups.has(nd)) groups.set(nd, []);
    groups.get(nd).push(actor);
  }

  const errors = [];
  const nds = ND_ORDER.filter(nd => groups.has(nd)).concat([...groups.keys()].filter(nd => !ND_ORDER.includes(nd)).sort());
  for (const nd of nds) {
    const group = groups.get(nd) ?? [];
    const folderName = ndFolderLabel(nd);
    let folder = game.folders.find(f => f.type === "Actor" && f.name === folderName && f.folder?.id === root.id) ?? null;
    if (!folder) folder = await Folder.create({ name: folderName, type: "Actor", folder: root.id });
    for (const source of group) {
      try {
        const data = cleanActor(source);
        await hydrateActorData(data);
        data.folder = folder.id;
        const embeddedItems = Array.isArray(data.items) ? data.items : [];
        data.items = [];
        const [createdActor] = await Actor.implementation.createDocuments([data]);
        if (embeddedItems.length) {
          await createdActor.createEmbeddedDocuments("Item", embeddedItems, { statblockParsing: true });
        }
      } catch (err) {
        errors.push({ nd, name: source.name, error: err?.message ?? String(err) });
      }
    }
  }
  return { imported: actors.length - errors.length, errors };
}

async function listLegacyNDPacks() {
  return [...game.packs.values()].filter(p => p.collection.startsWith("world.ameacas-de-arton-nd-"));
}

async function removeLegacyNDPacks() {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode remover compêndios antigos.");
  const packs = await listLegacyNDPacks();
  for (const pack of packs) {
    try { await pack.configure({ locked: false }); } catch (_) {}
    await pack.deleteCompendium();
  }
  if (packs.length) ui.notifications.info(`Ameaças de Arton: ${packs.length} compêndios antigos por ND removidos.`);
  return packs.length;
}

Hooks.once("ready", async () => {
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = {
    rebuildCompendium,
    rebuildCompendiums,
    importAllToWorld,
    loadActors,
    removeLegacyNDPacks,
    listLegacyNDPacks,
    packName: () => PACK_NAME,
    packLabel: () => "Ameaças de Arton",
    ndOrder: () => [...ND_ORDER],
    validateActorNDs,
    hydrateActorData,
    getNativeCatalog
  };
  if (!game.user?.isGM) return;

  const current = mod?.version ?? "1.2.0";
  const done = game.settings.get(MODULE_ID, "importedVersion");
  const hasPack = game.packs.has(PACK_COLLECTION);
  if (done === current && hasPack) return;

  try {
    const report = await rebuildCompendium({ notify: true });
    await game.settings.set(MODULE_ID, "importedVersion", current);
    if (!report.errors.length) console.info(`${MODULE_ID} | Importação concluída sem erros`, report);

    const legacy = await listLegacyNDPacks();
    if (legacy.length) {
      ui.notifications.warn(`Ameaças de Arton: o novo compêndio único está pronto. Ainda existem ${legacy.length} compêndios antigos por ND. Eles não foram apagados automaticamente para preservar possíveis edições.`);
    }
  } catch (err) {
    console.error(`${MODULE_ID} | Falha geral ao criar o compêndio`, err);
    ui.notifications.error(`Ameaças de Arton: falha geral. Abra F12 > Console. ${err?.message ?? err}`);
  }
});
