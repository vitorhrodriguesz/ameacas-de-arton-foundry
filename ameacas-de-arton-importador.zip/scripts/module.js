const MODULE_ID = "ameacas-de-arton-importador";
const DATA_URL = new URL("../data/actors.json", import.meta.url);

const ND_ORDER = ["1/4", "1/2", ...Array.from({length: 20}, (_, i) => String(i + 1)), "S", "S+", "?"];

function ndSlug(nd) {
  if (nd === "1/4") return "1-4";
  if (nd === "1/2") return "1-2";
  if (nd === "S+") return "s-plus";
  if (nd === "S") return "s";
  if (nd === "?") return "dinamico";
  return String(nd).replace(/[^a-z0-9-]/gi, "-").toLowerCase();
}

function ndLabel(nd) {
  if (/^\d+$/.test(nd)) return String(Number(nd)).padStart(2, "0");
  return nd;
}

function packName(nd) {
  return `ameacas-de-arton-nd-${ndSlug(nd)}`;
}

function packLabel(nd) {
  return `Ameaças de Arton — ND ${ndLabel(nd)}`;
}

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "importedVersion", {
    name: "Versão já importada",
    scope: "world",
    config: false,
    type: String,
    default: ""
  });
  game.settings.register(MODULE_ID, "lastImportReport", {
    name: "Relatório da última importação",
    scope: "world",
    config: false,
    type: Object,
    default: {}
  });
});

async function loadActors() {
  const response = await fetch(DATA_URL);
  if (!response.ok) throw new Error(`Não foi possível ler actors.json (${response.status}).`);
  const data = await response.json();
  if (!Array.isArray(data)) throw new Error("actors.json não contém uma lista de atores.");
  return data;
}

function cleanEmbeddedItem(item) {
  const i = foundry.utils.deepClone(item);
  delete i._id;
  delete i._stats;
  delete i.folder;
  delete i.ownership;
  return i;
}

function cleanActor(actor) {
  const a = foundry.utils.deepClone(actor);
  // IDs e metadados de exportação não devem ser reutilizados ao criar documentos em packs.
  delete a._id;
  delete a._stats;
  delete a.folder;
  delete a.ownership;
  if (Array.isArray(a.items)) a.items = a.items.map(cleanEmbeddedItem);
  return a;
}

async function ensurePack(nd) {
  const name = packName(nd);
  const collection = `world.${name}`;
  let pack = game.packs.get(collection);
  if (pack) return pack;
  const CC = globalThis.foundry?.documents?.collections?.CompendiumCollection ?? globalThis.CompendiumCollection;
  if (!CC?.createCompendium) throw new Error("API CompendiumCollection.createCompendium não encontrada.");
  pack = await CC.createCompendium({
    name,
    label: packLabel(nd),
    type: "Actor",
    package: "world",
    system: "tormenta20",
    ownership: { PLAYER: "LIMITED", ASSISTANT: "OWNER" }
  });
  return pack;
}

async function clearPack(pack) {
  try { await pack.configure({ locked: false }); } catch (_) {}
  const existing = await pack.getDocuments();
  if (existing.length) {
    await Actor.implementation.deleteDocuments(existing.map(d => d.id), { pack: pack.collection });
  }
}

async function createActorsResilient(pack, sourceActors, report) {
  let created = 0;
  // Um documento por operação é mais lento, mas evita que uma ficha problemática derrube um lote inteiro.
  for (const source of sourceActors) {
    try {
      await Actor.implementation.createDocuments([cleanActor(source)], { pack: pack.collection });
      created++;
    } catch (err) {
      const entry = { nd: source.system?.attributes?.nd ?? "?", name: source.name, error: err?.message ?? String(err) };
      report.errors.push(entry);
      console.error(`${MODULE_ID} | Falha ao importar ${source.name}`, err, source);
    }
  }
  return created;
}

async function rebuildCompendiums({ notify = true } = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode criar/atualizar os compêndios.");
  if (game.system.id !== "tormenta20") throw new Error("Este módulo deve ser usado no sistema Tormenta20.");

  const actors = await loadActors();
  const groups = new Map();
  for (const actor of actors) {
    const nd = String(actor.system?.attributes?.nd ?? "?");
    if (!groups.has(nd)) groups.set(nd, []);
    groups.get(nd).push(actor);
  }

  const presentNDs = ND_ORDER.filter(nd => groups.has(nd)).concat([...groups.keys()].filter(nd => !ND_ORDER.includes(nd)).sort());
  const report = { version: game.modules.get(MODULE_ID)?.version ?? "", total: actors.length, created: 0, packs: {}, errors: [], timestamp: Date.now() };

  for (const nd of presentNDs) {
    const pack = await ensurePack(nd);
    await clearPack(pack);
    const group = groups.get(nd) ?? [];
    if (notify) ui.notifications.info(`Ameaças de Arton: ND ${nd} — importando ${group.length} fichas...`);
    const created = await createActorsResilient(pack, group, report);
    report.created += created;
    report.packs[nd] = { requested: group.length, created, collection: pack.collection };
    try { await pack.configure({ locked: true }); } catch (_) {}
  }

  await game.settings.set(MODULE_ID, "lastImportReport", report);
  if (report.errors.length) {
    ui.notifications.warn(`Ameaças de Arton: ${report.created}/${report.total} fichas importadas; ${report.errors.length} falharam. Veja o console (F12) e game.settings.get('${MODULE_ID}', 'lastImportReport').`);
  } else if (notify) {
    ui.notifications.info(`Ameaças de Arton: ${report.created} fichas prontas, separadas por ND.`);
  }
  return report;
}

async function importAllToWorld({ rootFolderName = "Ameaças de Arton" } = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode importar fichas para o mundo.");
  const actors = await loadActors();
  let root = game.folders.find(f => f.type === "Actor" && f.name === rootFolderName && !f.folder) ?? null;
  if (!root) root = await Folder.create({ name: rootFolderName, type: "Actor" });

  const groups = new Map();
  for (const actor of actors) {
    const nd = String(actor.system?.attributes?.nd ?? "?");
    if (!groups.has(nd)) groups.set(nd, []);
    groups.get(nd).push(actor);
  }
  const errors = [];
  for (const [nd, group] of groups) {
    let folder = game.folders.find(f => f.type === "Actor" && f.name === `ND ${nd}` && f.folder?.id === root.id) ?? null;
    if (!folder) folder = await Folder.create({ name: `ND ${nd}`, type: "Actor", folder: root.id });
    for (const source of group) {
      try {
        const data = cleanActor(source);
        data.folder = folder.id;
        await Actor.implementation.createDocuments([data]);
      } catch (err) {
        errors.push({ nd, name: source.name, error: err?.message ?? String(err) });
      }
    }
  }
  return { imported: actors.length - errors.length, errors };
}

Hooks.once("ready", async () => {
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = { rebuildCompendiums, importAllToWorld, loadActors, packName, packLabel };
  if (!game.user?.isGM) return;
  const current = mod?.version ?? "1.1.0";
  const done = game.settings.get(MODULE_ID, "importedVersion");
  const hasAnyPack = [...game.packs.keys()].some(k => k.startsWith("world.ameacas-de-arton-nd-"));
  if (done === current && hasAnyPack) return;

  try {
    ui.notifications.info("Ameaças de Arton: criando compêndios por ND. A primeira importação pode levar alguns minutos...");
    const report = await rebuildCompendiums({ notify: true });
    await game.settings.set(MODULE_ID, "importedVersion", current);
    if (!report.errors.length) console.info(`${MODULE_ID} | Importação concluída sem erros`, report);
  } catch (err) {
    console.error(`${MODULE_ID} | Falha geral ao criar os compêndios`, err);
    ui.notifications.error(`Ameaças de Arton: falha geral. Abra F12 > Console. ${err?.message ?? err}`);
  }
});
