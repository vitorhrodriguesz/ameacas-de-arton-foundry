const MODULE_ID = "ameacas-de-arton-importador";
const PACK_NAME = "ameacas-de-arton";
const PACK_COLLECTION = `world.${PACK_NAME}`;
const DATA_URL = new URL("../data/actors.json", import.meta.url);

// Ordem visual do compêndio: NDs fracionários, 1 a 20, depois NDs em letras e o ND dinâmico.
const ND_ORDER = ["1/4", "1/2", ...Array.from({length: 20}, (_, i) => String(i + 1)), "S", "S+", "?"];

function ndSortKey(nd) {
  const i = ND_ORDER.indexOf(nd);
  return i >= 0 ? i : ND_ORDER.length + 100;
}

function ndFolderLabel(nd) {
  if (nd === "?") return "ND Dinâmico (?)";
  return `ND ${nd}`;
}

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "importedVersion", {
    name: "Versão já importada",
    scope: "world",
    config: false,
    type: String,
    default: ""
  });
  game.settings.register(MODULE_ID, "lastImportReport", {
    name: "Relatório da última importação",
    scope: "world",
    config: false,
    type: Object,
    default: {}
  });
});

async function loadActors() {
  const response = await fetch(DATA_URL);
  if (!response.ok) throw new Error(`Não foi possível ler actors.json (${response.status}).`);
  const data = await response.json();
  if (!Array.isArray(data)) throw new Error("actors.json não contém uma lista de atores.");
  return data;
}

function cleanEmbeddedItem(item) {
  const i = foundry.utils.deepClone(item);
  delete i._id;
  delete i._stats;
  delete i.folder;
  delete i.ownership;
  return i;
}

function cleanActor(actor) {
  const a = foundry.utils.deepClone(actor);
  delete a._id;
  delete a._stats;
  delete a.folder;
  delete a.ownership;
  if (Array.isArray(a.items)) a.items = a.items.map(cleanEmbeddedItem);
  return a;
}

function getCompendiumClass() {
  return globalThis.foundry?.documents?.collections?.CompendiumCollection ?? globalThis.CompendiumCollection;
}

async function ensureSinglePack({ recreate = false } = {}) {
  let pack = game.packs.get(PACK_COLLECTION);
  if (pack && recreate) {
    try { await pack.configure({ locked: false }); } catch (_) {}
    await pack.deleteCompendium();
    pack = null;
  }
  if (pack) return pack;

  const CC = getCompendiumClass();
  if (!CC?.createCompendium) throw new Error("API CompendiumCollection.createCompendium não encontrada.");
  return await CC.createCompendium({
    name: PACK_NAME,
    label: "Ameaças de Arton",
    type: "Actor",
    package: "world",
    system: "tormenta20",
    ownership: { PLAYER: "LIMITED", ASSISTANT: "OWNER" }
  });
}

async function createNDFolders(pack, nds) {
  const folderData = nds.map((nd, index) => ({
    name: ndFolderLabel(nd),
    type: "Actor",
    folder: null,
    // Conteúdo da pasta (atores) em ordem alfabética.
    sorting: "a",
    // Pastas de nível superior usam sort manual no Foundry; isso fixa a ordem ND.
    sort: (index + 1) * 100000,
    flags: { [MODULE_ID]: { nd } }
  }));

  // Foundry v13 permite Folder dentro de Compendium via {pack}.
  const created = await Folder.createDocuments(folderData, { pack: pack.collection });

  // IMPORTANTE: não associar por índice do array retornado. O Foundry pode devolver
  // os documentos em uma ordem diferente da enviada. Essa era a origem possível de
  // fichas ND 3 aparecerem em pasta ND 2 (e vice-versa).
  const byND = new Map();
  const labelToND = new Map(nds.map(nd => [ndFolderLabel(nd), nd]));
  for (const folder of created) {
    const flaggedND = folder.flags?.[MODULE_ID]?.nd;
    const nd = flaggedND != null ? String(flaggedND) : labelToND.get(folder.name);
    if (nd && nds.includes(nd)) byND.set(nd, folder);
  }

  const missing = nds.filter(nd => !byND.has(nd));
  if (missing.length) {
    throw new Error(`Falha ao mapear pastas de ND: ${missing.join(", ")}`);
  }

  // Validação defensiva: a pasta vinculada a cada ND deve ter o nome esperado.
  for (const nd of nds) {
    const folder = byND.get(nd);
    const expected = ndFolderLabel(nd);
    if (folder?.name !== expected) {
      throw new Error(`Pasta de ND inconsistente: ND ${nd} foi associado a "${folder?.name}"; esperado "${expected}".`);
    }
  }
  return byND;
}

async function createActorsResilient(pack, sourceActors, folderByND, report) {
  let created = 0;
  for (const source of sourceActors) {
    const nd = String(source.system?.attributes?.nd ?? "?");
    try {
      const data = cleanActor(source);
      const folder = folderByND.get(nd);
      if (folder) data.folder = folder.id;
      await Actor.implementation.createDocuments([data], { pack: pack.collection });
      created++;
      report.folders[nd].created++;
    } catch (err) {
      const entry = { nd, name: source.name, error: err?.message ?? String(err) };
      report.errors.push(entry);
      console.error(`${MODULE_ID} | Falha ao importar ${source.name}`, err, source);
    }
  }
  return created;
}

function validateActorNDs(actors) {
  const allowed = new Set(ND_ORDER);
  const invalid = [];
  for (const actor of actors) {
    const nd = String(actor.system?.attributes?.nd ?? "?");
    if (!allowed.has(nd)) invalid.push({ name: actor.name, nd });
  }
  if (invalid.length) {
    throw new Error(`Há ${invalid.length} ficha(s) com ND fora da lista suportada: ${invalid.map(e => `${e.name} (${e.nd})`).join(", ")}`);
  }
  return true;
}

/**
 * Recria UM único Compendium "Ameaças de Arton" e cria pastas internas por ND.
 * O pack alvo é recriado para garantir que não sobrem pastas/documentos de versões anteriores.
 */
async function rebuildCompendium({ notify = true } = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode criar/atualizar o compêndio.");
  if (game.system.id !== "tormenta20") throw new Error("Este módulo deve ser usado no sistema Tormenta20.");

  const actors = await loadActors();
  validateActorNDs(actors);
  const present = new Set(actors.map(a => String(a.system?.attributes?.nd ?? "?")));
  const nds = ND_ORDER.filter(nd => present.has(nd))
    .concat([...present].filter(nd => !ND_ORDER.includes(nd)).sort((a, b) => ndSortKey(a) - ndSortKey(b) || a.localeCompare(b, "pt-BR")));

  if (notify) ui.notifications.info("Ameaças de Arton: recriando um único compêndio com pastas por ND...");
  const pack = await ensureSinglePack({ recreate: true });
  try { await pack.configure({ locked: false }); } catch (_) {}

  const folderByND = await createNDFolders(pack, nds);
  const report = {
    version: game.modules.get(MODULE_ID)?.version ?? "",
    total: actors.length,
    created: 0,
    pack: pack.collection,
    folders: {},
    errors: [],
    timestamp: Date.now()
  };
  for (const nd of nds) {
    report.folders[nd] = {
      name: ndFolderLabel(nd),
      requested: actors.filter(a => String(a.system?.attributes?.nd ?? "?") === nd).length,
      created: 0,
      folderId: folderByND.get(nd)?.id ?? null
    };
  }

  report.created = await createActorsResilient(pack, actors, folderByND, report);
  try { await pack.configure({ locked: true }); } catch (_) {}

  await game.settings.set(MODULE_ID, "lastImportReport", report);
  if (report.errors.length) {
    ui.notifications.warn(`Ameaças de Arton: ${report.created}/${report.total} fichas importadas; ${report.errors.length} falharam. Veja F12 e game.settings.get('${MODULE_ID}', 'lastImportReport').`);
  } else if (notify) {
    ui.notifications.info(`Ameaças de Arton: ${report.created} fichas em um único compêndio, organizadas por ND.`);
  }
  return report;
}

// Alias para comandos usados na versão 1.1.
const rebuildCompendiums = rebuildCompendium;

async function importAllToWorld({ rootFolderName = "Ameaças de Arton" } = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode importar fichas para o mundo.");
  const actors = await loadActors();
  let root = game.folders.find(f => f.type === "Actor" && f.name === rootFolderName && !f.folder) ?? null;
  if (!root) root = await Folder.create({ name: rootFolderName, type: "Actor" });

  const groups = new Map();
  for (const actor of actors) {
    const nd = String(actor.system?.attributes?.nd ?? "?");
    if (!groups.has(nd)) groups.set(nd, []);
    groups.get(nd).push(actor);
  }

  const errors = [];
  const nds = ND_ORDER.filter(nd => groups.has(nd)).concat([...groups.keys()].filter(nd => !ND_ORDER.includes(nd)).sort());
  for (const nd of nds) {
    const group = groups.get(nd) ?? [];
    const folderName = ndFolderLabel(nd);
    let folder = game.folders.find(f => f.type === "Actor" && f.name === folderName && f.folder?.id === root.id) ?? null;
    if (!folder) folder = await Folder.create({ name: folderName, type: "Actor", folder: root.id });
    for (const source of group) {
      try {
        const data = cleanActor(source);
        data.folder = folder.id;
        await Actor.implementation.createDocuments([data]);
      } catch (err) {
        errors.push({ nd, name: source.name, error: err?.message ?? String(err) });
      }
    }
  }
  return { imported: actors.length - errors.length, errors };
}

async function listLegacyNDPacks() {
  return [...game.packs.values()].filter(p => p.collection.startsWith("world.ameacas-de-arton-nd-"));
}

async function removeLegacyNDPacks() {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode remover compêndios antigos.");
  const packs = await listLegacyNDPacks();
  for (const pack of packs) {
    try { await pack.configure({ locked: false }); } catch (_) {}
    await pack.deleteCompendium();
  }
  if (packs.length) ui.notifications.info(`Ameaças de Arton: ${packs.length} compêndios antigos por ND removidos.`);
  return packs.length;
}

Hooks.once("ready", async () => {
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = {
    rebuildCompendium,
    rebuildCompendiums,
    importAllToWorld,
    loadActors,
    removeLegacyNDPacks,
    listLegacyNDPacks,
    packName: () => PACK_NAME,
    packLabel: () => "Ameaças de Arton",
    ndOrder: () => [...ND_ORDER],
    validateActorNDs
  };
  if (!game.user?.isGM) return;

  const current = mod?.version ?? "1.2.0";
  const done = game.settings.get(MODULE_ID, "importedVersion");
  const hasPack = game.packs.has(PACK_COLLECTION);
  if (done === current && hasPack) return;

  try {
    const report = await rebuildCompendium({ notify: true });
    await game.settings.set(MODULE_ID, "importedVersion", current);
    if (!report.errors.length) console.info(`${MODULE_ID} | Importação concluída sem erros`, report);

    const legacy = await listLegacyNDPacks();
    if (legacy.length) {
      ui.notifications.warn(`Ameaças de Arton: o novo compêndio único está pronto. Ainda existem ${legacy.length} compêndios antigos por ND. Eles não foram apagados automaticamente para preservar possíveis edições.`);
    }
  } catch (err) {
    console.error(`${MODULE_ID} | Falha geral ao criar o compêndio`, err);
    ui.notifications.error(`Ameaças de Arton: falha geral. Abra F12 > Console. ${err?.message ?? err}`);
  }
});
