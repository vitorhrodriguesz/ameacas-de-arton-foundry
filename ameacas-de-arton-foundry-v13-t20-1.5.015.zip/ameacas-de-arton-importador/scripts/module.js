const MODULE_ID = "ameacas-de-arton-importador";
const PACK_NAME = "ameacas-de-arton";
const PACK_LABEL = "Ameaças de Arton";
const DATA_URL = `modules/${MODULE_ID}/data/actors.json`;

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "importedVersion", {
    name: "Versão já importada",
    scope: "world",
    config: false,
    type: String,
    default: ""
  });
});

async function loadActors() {
  const response = await fetch(DATA_URL);
  if (!response.ok) throw new Error(`Não foi possível ler ${DATA_URL}: ${response.status}`);
  return await response.json();
}

async function ensurePack() {
  const collection = `world.${PACK_NAME}`;
  let pack = game.packs.get(collection);
  if (pack) return pack;
  const CC = foundry?.documents?.collections?.CompendiumCollection ?? globalThis.CompendiumCollection;
  if (!CC?.createCompendium) throw new Error("API de criação de compêndios não encontrada no Foundry.");
  pack = await CC.createCompendium({
    label: PACK_LABEL,
    name: PACK_NAME,
    type: "Actor",
    system: "tormenta20"
  });
  return pack;
}

async function rebuildCompendium({ notify = true } = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode criar/atualizar o compêndio.");
  if (game.system.id !== "tormenta20") throw new Error("Este módulo deve ser usado no sistema Tormenta20.");
  const actors = await loadActors();
  const pack = await ensurePack();
  try { await pack.configure({locked: false}); } catch (_) {}
  const existing = await pack.getDocuments();
  if (existing.length) await Actor.implementation.deleteDocuments(existing.map(d => d.id), {pack: pack.collection});
  const batchSize = 25;
  for (let i=0; i<actors.length; i+=batchSize) {
    const batch = actors.slice(i, i+batchSize);
    await Actor.implementation.createDocuments(batch, {pack: pack.collection});
    if (notify && (i===0 || i+batchSize>=actors.length || i%100===0)) {
      ui.notifications.info(`Ameaças de Arton: importando ${Math.min(i+batchSize,actors.length)}/${actors.length}...`);
    }
  }
  try { await pack.configure({locked: true}); } catch (_) {}
  if (notify) ui.notifications.info(`Ameaças de Arton: ${actors.length} fichas prontas no compêndio “${PACK_LABEL}”.`);
  return pack;
}

async function importAllToWorld({folderName = "Ameaças de Arton"} = {}) {
  if (!game.user?.isGM) throw new Error("Apenas um Mestre pode importar fichas para o mundo.");
  const pack = game.packs.get(`world.${PACK_NAME}`) ?? await rebuildCompendium({notify:true});
  return await pack.importAll({folderName});
}

Hooks.once("ready", async () => {
  const mod = game.modules.get(MODULE_ID);
  if (mod) mod.api = { rebuildCompendium, importAllToWorld, loadActors };
  if (!game.user?.isGM) return;
  const current = mod?.version ?? "1.0.0";
  const done = game.settings.get(MODULE_ID, "importedVersion");
  if (done === current && game.packs.get(`world.${PACK_NAME}`)) return;
  try {
    ui.notifications.info("Ameaças de Arton: criando o compêndio. Isso pode levar alguns instantes...");
    await rebuildCompendium({notify:true});
    await game.settings.set(MODULE_ID, "importedVersion", current);
  } catch (err) {
    console.error(`${MODULE_ID} | Falha ao criar o compêndio`, err);
    ui.notifications.error(`Ameaças de Arton: falha ao criar o compêndio. Veja o console (F12). ${err.message}`);
  }
});
