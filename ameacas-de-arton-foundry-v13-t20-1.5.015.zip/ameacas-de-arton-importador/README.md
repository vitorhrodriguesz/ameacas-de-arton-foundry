# Ameaças de Arton — Foundry VTT 13 / Tormenta20 1.5.015

Este módulo contém **430 fichas de Actor** extraídas do arquivo *Ameaças de Arton* fornecido nesta conversa.

## Instalação
1. Feche o Foundry VTT.
2. Extraia a pasta `ameacas-de-arton-foundry-v13-t20-1.5.015` para `Data/modules/`.
3. Se necessário, renomeie a pasta instalada para `ameacas-de-arton-importador` (o nome do diretório precisa corresponder ao `id` do `module.json`).
4. Abra seu mundo Tormenta20 e ative **Ameaças de Arton — Compêndio Importável**.
5. Ao entrar como Mestre, o módulo cria/atualiza automaticamente um compêndio de mundo chamado **Ameaças de Arton** com todas as fichas.
6. Arraste qualquer criatura do compêndio para o mundo/cena. Para importar todas as fichas de uma vez, abra o console (F12) e execute:
   `game.modules.get("ameacas-de-arton-importador").api.importAllToWorld()`

## Atualizar/recriar o compêndio
No console (F12):
`game.modules.get("ameacas-de-arton-importador").api.rebuildCompendium()`

## Conteúdo e compatibilidade
- Foundry VTT: 13
- Sistema: `tormenta20` 1.5.015
- Fichas: 430
- Imagens/tokens: placeholders genéricos do Foundry (as ilustrações do PDF não foram redistribuídas como arquivos de imagem).
- Ataques reconhecidos foram transformados em itens `arma` com rolagem de ataque estática igual ao bônus impresso e dano quando a fórmula pôde ser lida.
- Habilidades reconhecidas pela tipografia do bloco foram transformadas em itens `poder`.
- O bloco de estatísticas original extraído do PDF é mantido na biografia da ficha para conferência.
- A criatura **Rival Espelho** é dinâmica no próprio livro; por isso sua ficha registra a regra de cópia, em vez de inventar estatísticas fixas.

## Validação
`data/validation.json` lista cada criatura, página, ND, quantidade de itens embutidos e eventuais exceções de conversão.
